import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QGridLayout, QLineEdit
)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QPixmap, QImage
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge


from PyQt5.QtCore import pyqtSignal, QObject
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge
from PyQt5.QtGui import QImage

class ROSNode(Node, QObject):
    # Define signals
    status_updated = pyqtSignal(str)
    hand_eye_updated = pyqtSignal(QImage)
    world_eye_updated = pyqtSignal(QImage)

    def __init__(self):
        Node.__init__(self, 'gui_node')
        QObject.__init__(self)

        # 퍼블리셔 생성
        self.status_pub = self.create_publisher(String, 'robot_status', 10)
        self.conveyor_pub = self.create_publisher(String, 'conveyor_status', 10)
        self.study_start_pub = self.create_publisher(String, 'study_start', 10)

        # 구독자 생성
        self.status_sub = self.create_subscription(
            String, 'status_topic', self.handle_status_update, 10)
        self.hand_eye_sub = self.create_subscription(
            Image, 'status_image', self.update_hand_eye, 10)
        self.world_eye_sub = self.create_subscription(
            Image, 'webcam_image', self.update_world_eye, 10)

        # OpenCV 브리지 초기화
        self.bridge = CvBridge()

    def handle_status_update(self, msg):
        """status_topic에서 상태를 수신하여 GUI에 전달"""
        self.status_updated.emit(msg.data)
        self.get_logger().info(f"Received state: {msg.data}")

    def update_hand_eye(self, msg):
        """Hand-eye 이미지를 GUI에 표시"""
        cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        height, width, channel = cv_image.shape
        bytes_per_line = 3 * width
        q_img = QImage(cv_image.data, width, height, bytes_per_line, QImage.Format_RGB888)
        self.hand_eye_updated.emit(q_img)

    def update_world_eye(self, msg):
        """World-eye 이미지를 GUI에 표시"""
        cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        height, width, channel = cv_image.shape
        bytes_per_line = 3 * width
        q_img = QImage(cv_image.data, width, height, bytes_per_line, QImage.Format_RGB888)
        self.world_eye_updated.emit(q_img)



class LoginWindow(QWidget):
    def __init__(self, ros_node):
        super().__init__()
        self.ros_node = ros_node

        self.setWindowTitle("Login")
        self.setGeometry(100, 100, 300, 200)

        self.username = QLineEdit()
        self.username.setPlaceholderText("Username")
        self.password = QLineEdit()
        self.password.setPlaceholderText("Password")
        self.password.setEchoMode(QLineEdit.Password)

        self.login_button = QPushButton("Login")
        self.login_button.clicked.connect(self.check_login)

        self.error_label = QLabel()
        self.error_label.setStyleSheet("color: red;")

        layout = QVBoxLayout()
        layout.addWidget(self.username)
        layout.addWidget(self.password)
        layout.addWidget(self.login_button)
        layout.addWidget(self.error_label)

        self.setLayout(layout)

    def check_login(self):
        if self.username.text() == "rokey" and self.password.text() == "rokey1234":
            self.close()
            self.main_window = RobotGUI(self.ros_node)
            self.main_window.show()
        else:
            self.error_label.setText("Invalid username or password")

class RobotGUI(QWidget):
    def __init__(self, ros_node):
        super().__init__()
        self.ros_node = ros_node
        
        # 연결: ROSNode 시그널과 슬롯
        self.ros_node.status_updated.connect(self.update_status)
        self.ros_node.hand_eye_updated.connect(self.update_hand_eye_image)
        self.ros_node.world_eye_updated.connect(self.update_world_eye_image)

        # 윈도우 기본 설정
        self.setWindowTitle("Robot Control GUI")
        self.setGeometry(100, 100, 1000, 700)

        # 버튼 클릭 횟수 저장
        self.red_count = 0
        self.blue_count = 0
        self.selected_goal = None

        # 전체 레이아웃
        main_layout = QVBoxLayout()

        # 상단 레이아웃 (World-eye, Hand-eye, Time, Robot Status)
        top_layout = QHBoxLayout()

        self.world_eye = QLabel("World-eye")
        self.world_eye.setStyleSheet("border: 2px solid black;")
        self.world_eye.setFixedSize(350, 250)
        self.world_eye.setAlignment(Qt.AlignCenter)  # 텍스트 가운데 정렬

        self.hand_eye = QLabel("Hand-eye")
        self.hand_eye.setStyleSheet("border: 2px solid black;")
        self.hand_eye.setFixedSize(350, 250)
        self.hand_eye.setAlignment(Qt.AlignCenter)  # 텍스트 가운데 정렬

        self.time_display = QLabel("Time: 0s")
        self.time_display.setStyleSheet("border: 2px solid black; padding: 5px;")
        self.time_display.setAlignment(Qt.AlignCenter)
        self.time_display.setFixedSize(150, 50)

        self.robot_status = QLabel("Robot Status: Idle")
        self.robot_status.setStyleSheet("border: 2px solid black; padding: 5px;")
        self.robot_status.setAlignment(Qt.AlignCenter)
        self.robot_status.setFixedSize(150, 50)

        # 상단 레이아웃 추가
        top_layout.addWidget(self.world_eye)
        top_layout.addWidget(self.hand_eye)
        right_top_layout = QVBoxLayout()
        right_top_layout.addWidget(self.time_display)
        right_top_layout.addWidget(self.robot_status)
        right_top_layout.addStretch()
        top_layout.addLayout(right_top_layout)

        # 중간 버튼 레이아웃
        button_layout = QGridLayout()

        # 버튼 크기 스타일 설정
        button_style = "padding: 10px; font-size: 12px;"

        # Robot 버튼
        robot_label = QLabel("Robot")
        robot_label.setAlignment(Qt.AlignLeft)
        button_layout.addWidget(robot_label, 0, 0, 1, 5)
        self.robot_buttons = {
            "play": QPushButton("Play"),
            "stop": QPushButton("Stop"),
            "pause": QPushButton("Pause"),
            "resume": QPushButton("Resume"),
            "reset": QPushButton("Reset")
        }

        # 버튼의 고정 너비를 설정하여 크기를 통일
        button_width = 200  # 버튼 너비 설정

        for i, (name, button) in enumerate(self.robot_buttons.items()):
            button.setStyleSheet(button_style)
            button.setFixedWidth(button_width)  # 고정된 너비로 설정
            button.setFixedHeight(40)  # 버튼 크기 유지
            button_layout.addWidget(button, 1, i)

        # Conveyor 버튼
        conveyor_label = QLabel("Conveyor")
        conveyor_label.setAlignment(Qt.AlignLeft)
        button_layout.addWidget(conveyor_label, 3, 0, 1, 2)  # 위치를 아래로 내려줌
        self.conveyor_buttons = {
            "play": QPushButton("Play"),
            "stop": QPushButton("Stop")
        }
        for i, (name, button) in enumerate(self.conveyor_buttons.items()):
            button.setStyleSheet(button_style)
            button.setFixedWidth(button_width)  # 고정된 너비로 설정
            button.setFixedHeight(40)  # 버튼 크기 유지
            button_layout.addWidget(button, 4, i)

        # Red Box 숫자 입력 칸
        self.red_label = QLabel("Red Box")
        self.red_label.setAlignment(Qt.AlignLeft)
        button_layout.addWidget(self.red_label, 5, 0)
        self.red_input = QLineEdit()
        self.red_input.setPlaceholderText("Enter Red Box quantity")
        self.red_input.setFixedWidth(200)
        button_layout.addWidget(self.red_input, 5, 1)

        # Blue Box 숫자 입력 칸
        self.blue_label = QLabel("Blue Box")
        self.blue_label.setAlignment(Qt.AlignLeft)
        button_layout.addWidget(self.blue_label, 5, 2)
        self.blue_input = QLineEdit()
        self.blue_input.setPlaceholderText("Enter Blue Box quantity")
        self.blue_input.setFixedWidth(200)
        button_layout.addWidget(self.blue_input, 5, 3)
        
        # Commit 버튼
        self.commit_button = QPushButton("Commit")
        self.commit_button.setStyleSheet(button_style)
        self.commit_button.setFixedHeight(40)  # 버튼 크기 유지
        button_layout.addWidget(self.commit_button, 5, 4)

        # Goal 버튼 (토글 버튼으로 변경)
        goal_label = QLabel("Goal")
        goal_label.setAlignment(Qt.AlignLeft)
        button_layout.addWidget(goal_label, 7, 0, 1, 3)  # 위치를 버튼 바로 위로 이동

        self.goal_buttons = {
        "Goal1": QPushButton("Goal 1"),
        "Goal2": QPushButton("Goal 2"),
        "Goal3": QPushButton("Goal 3"),
        }

        # Goal 버튼 설정
        for i, (name, button) in enumerate(self.goal_buttons.items()):
            button.setCheckable(True)  # 버튼을 토글 가능하게 설정
            button.setStyleSheet(button_style)
            button.setFixedHeight(40)  # 버튼 크기 유지
            button.clicked.connect(self.handle_goal_button)  # 클릭 시 이벤트 처리
            button_layout.addWidget(button, 8, i)

        # Study Start 버튼을 위로 한 칸 올리기
        self.study_start_button = QPushButton("Study_start")
        self.study_start_button.setStyleSheet(button_style)
        self.study_start_button.setFixedHeight(40)  # 버튼 크기 유지
        button_layout.addWidget(self.study_start_button, 4, 4, 1, 1)  # 위로 한 칸 올림

        # 타이머 설정
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_time)
        self.time_elapsed = 0
        self.timer.start(1000)

        # 메인 레이아웃에 상단과 버튼 레이아웃 추가
        main_layout.addLayout(top_layout)
        main_layout.addLayout(button_layout)
        self.setLayout(main_layout)       

    def update_time(self):
        self.time_elapsed += 1
        self.time_display.setText(f"Time: {self.time_elapsed}s")
        self.ros_node.robot_status_pub.publish(String(data=f"Time elapsed: {self.time_elapsed}s"))

    def update_status(self, state):
        self.robot_status.setText(f"Robot Status: {state}")

    def update_hand_eye_image(self, image):
        self.hand_eye.setPixmap(QPixmap.fromImage(image))

    def update_world_eye_image(self, image):
        self.world_eye.setPixmap(QPixmap.fromImage(image))

    def handle_robot_button(self):
        sender = self.sender()
        self.robot_status.setText(f"Robot Status: {sender.text()}")
        self.ros_node.robot_status_pub.publish(String(data=f"Robot {sender.text()}"))

    def handle_conveyor_button(self):
        sender = self.sender()
        self.ros_node.conveyor_pub.publish(String(data=f"Conveyor {sender.text()}"))

    def handle_study_start_button(self):
        self.robot_status.setText("Study Started")
        self.ros_node.study_start_pub.publish(String(data="Study started"))
    
    def handle_goal_button(self):
        """Goal 버튼 클릭 시 선택된 Goal 업데이트"""
        sender = self.sender()  # 클릭한 버튼 객체 가져오기
        self.selected_goal = sender.text()  # 버튼의 텍스트(Goal1, Goal2, Goal3 등)를 선택된 Goal로 저장
    
    def handle_commit_button(self):

        try:
            # Red Box와 Blue Box 값 읽기
            red_quantity = int(self.red_input.text())
            blue_quantity = int(self.blue_input.text())
        except ValueError:
            # 유효하지 않은 입력은 메시지를 퍼블리시하지 않음
            return

        if not self.selected_goal:
            # Goal이 선택되지 않은 경우도 메시지를 퍼블리시하지 않음
            return

        # 메시지 생성
        commit_message = f"Red: {red_quantity}, Blue: {blue_quantity}, Goal: {self.selected_goal}"
    
        # ROS 퍼블리셔로 메시지 송신
        self.ros_node.commit_pub.publish(String(data=commit_message))

def main():
    rclpy.init()
    ros_node = ROSNode()

    app = QApplication(sys.argv)
    login_window = LoginWindow(ros_node)
    login_window.show()

    def ros_spin():
        rclpy.spin_once(ros_node, timeout_sec=0.1)

    timer = QTimer()
    timer.timeout.connect(ros_spin)
    timer.start(10)

    sys.exit(app.exec_())
    rclpy.shutdown()


if __name__ == "__main__":
    main()
