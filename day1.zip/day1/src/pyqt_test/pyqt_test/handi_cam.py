import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

class HandiCam(Node):
    def __init__(self):
        super().__init__('status_subscriber')
        
        # 구독자 생성
        self.subscription = self.create_subscription(
            String,
            'status_topic',
            self.status_callback,
            10)
        
        # 퍼블리셔 생성 (이미지 퍼블리시)
        self.image_publisher = self.create_publisher(Image, 'status_image', 10)
        
        # CvBridge 초기화
        self.bridge = CvBridge()

        # 상태별 이미지 경로 설정
        self.stop_image_path = '/home/booding/stop.jpeg'
        self.pick_image_path = '/home/booding/pick.jpeg'

        self.get_logger().info('StatusSubscriber node initialized.')

    def status_callback(self, msg):
        """상태 메시지를 처리하는 콜백 함수."""
        status = msg.data
        self.get_logger().info(f'Received status: {status}')
    
        # 상태에 따라 동작 수행
        if status in ('pick_initial_box', 'put_initial_box', 'pick_initial_basket', 'put_initial_goal'):
            self.publish_image(self.stop_image_path)
        elif status in ('pick_box', 'put_box', 'pick_basket', 'put_basket'):
            self.publish_image(self.pick_image_path)
        else:
            self.get_logger().info(f'Unhandled status received: {status}')
    

    
    def publish_image(self, image_path, compression_quality=90):
    
        # 이미지 로드
        image = cv2.imread(image_path)
        if image is None:
            self.get_logger().error(f"Failed to load image from {image_path}")
            return
    
        # 이미지 압축 (JPEG로 변환)
        encode_param = [cv2.IMWRITE_JPEG_QUALITY, compression_quality]
        success, encoded_image = cv2.imencode('.jpg', image, encode_param)
    
        if not success:
            self.get_logger().error("Failed to compress image")
            return
    
        # 디코딩하여 다시 OpenCV 이미지로 변환
        compressed_image = cv2.imdecode(encoded_image, cv2.IMREAD_COLOR)
    
        # OpenCV 이미지를 ROS 메시지로 변환
        image_msg = self.bridge.cv2_to_imgmsg(compressed_image, encoding='bgr8')
    
        # 퍼블리시
        self.image_publisher.publish(image_msg)
        self.get_logger().info(f"Published compressed image from {image_path} with quality {compression_quality}")



def main(args=None):
    rclpy.init(args=args)
    node = HandiCam()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
