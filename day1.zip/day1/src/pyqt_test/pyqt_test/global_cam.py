import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2


class WebcamImagePublisher(Node):
    def __init__(self):
        super().__init__('webcam_image_publisher')
        
        # 퍼블리셔 생성
        self.publisher_ = self.create_publisher(Image, 'webcam_image', 10)
        
        # CvBridge 객체 생성
        self.bridge = CvBridge()
        
        # OpenCV 웹캠 초기화
        self.cap = cv2.VideoCapture(0)  # 0번 카메라 (기본 웹캠)
        if not self.cap.isOpened():
            self.get_logger().error("Unable to open webcam.")
            raise RuntimeError("Webcam could not be opened.")
        
        # 주기적으로 이미지를 퍼블리시
        self.timer = self.create_timer(0.1, self.publish_image)  # 0.1초마다 실행 (10 FPS)
        self.get_logger().info("WebcamImagePublisher node initialized.")

    def publish_image(self, compression_quality=90):
   
        ret, frame = self.cap.read()
        if not ret:
            self.get_logger().warn("Failed to capture image from webcam.")
            return
    
        # 이미지 압축 (JPEG로 변환)
        encode_param = [cv2.IMWRITE_JPEG_QUALITY, compression_quality]
        success, encoded_image = cv2.imencode('.jpg', frame, encode_param)
    
        if not success:
            self.get_logger().error("Failed to compress image")
            return
    
        # 디코딩하여 다시 OpenCV 이미지로 변환
        compressed_frame = cv2.imdecode(encoded_image, cv2.IMREAD_COLOR)
    
        # OpenCV 이미지를 ROS 메시지로 변환
        image_message = self.bridge.cv2_to_imgmsg(compressed_frame, encoding='bgr8')
    
        # 이미지 퍼블리시
        self.publisher_.publish(image_message)
        self.get_logger().info(f"Published compressed webcam image with quality {compression_quality}")

    def destroy_node(self):
        """노드 종료 시 리소스 정리"""
        self.cap.release()  # 웹캠 리소스 해제
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = WebcamImagePublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
